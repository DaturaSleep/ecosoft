package com.vmaksym.ecosoft;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcosoftApplicationTests {

    @Test
    void contextLoads() {
    }

}
