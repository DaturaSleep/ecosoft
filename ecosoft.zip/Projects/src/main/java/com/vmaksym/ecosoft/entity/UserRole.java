package com.vmaksym.ecosoft.entity;

public enum UserRole {
    ADMIN("ADMIN"), TEACHER("TEACHER"), PUPIL("PUPIL");

    public String roleName;

    UserRole(String roleName) {
    this.roleName = roleName;
    }
}
