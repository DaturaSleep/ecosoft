package com.vmaksym.ecosoft;

import com.vmaksym.ecosoft.entity.ApplicationUser;
import com.vmaksym.ecosoft.entity.UserRole;
import com.vmaksym.ecosoft.repo.ApplicationUserRepo;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import javax.annotation.PostConstruct;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

@SpringBootApplication
public class EcosoftApplication {

    final ApplicationUserRepo applicationUserRepo;


    public EcosoftApplication(ApplicationUserRepo applicationUserRepo) {
        this.applicationUserRepo = applicationUserRepo;
    }

    @PostConstruct
    public void initTestUsers() {
        applicationUserRepo.save(new ApplicationUser(1, "iviti", "strongSecurity", new HashSet<>(Arrays.asList(UserRole.ADMIN))));
        applicationUserRepo.save(new ApplicationUser(2, "adamanti", "weak", new HashSet<>(Arrays.asList(UserRole.PUPIL))));
        applicationUserRepo.save(new ApplicationUser(3, "test", "test", new HashSet<>(Arrays.asList(UserRole.TEACHER, UserRole.PUPIL))));
        applicationUserRepo.save(new ApplicationUser(4, "admin", "admin", new HashSet<>(Arrays.asList(UserRole.ADMIN))));
    }

    public static void main(String[] args) {
        SpringApplication.run(EcosoftApplication.class, args);
    }

}
